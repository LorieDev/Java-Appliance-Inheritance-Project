package com.LorieProject;

public class WashingMachine extends Appliance {


    //Field
    private String loadCapacity;


    public WashingMachine(String brand, String watts, String loadCapacity) {
        super(brand, watts);
        this.loadCapacity = loadCapacity;
    }

    //Getter
    public String getLoadCapacity(){
        return this.loadCapacity;
    }

    //Setter
    public void setLoadCapacity(String loadCapacity){
        this.loadCapacity = loadCapacity;
    }



    //Methods
    public void startWashCycle(){
        System.out.println("Your washing machine has started the wash cycle.");
    }

}