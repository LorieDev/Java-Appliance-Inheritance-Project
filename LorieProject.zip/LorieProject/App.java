package com.LorieProject;

public class App{
    public static void main(String [] args){

        //Create Methods
        WashingMachine washingMachine = new WashingMachine("GE", "123w", "9kg");
        Refrigerator refrigerator = new Refrigerator("Samsung", "200w", "4°C");

        //Call
        washingMachine.turnOn();

        refrigerator.turnOn();

        //Print info
        System.out.println("Brand: " + washingMachine.getBrand());
        System.out.println("Load Capacity: " + washingMachine.getLoadCapacity());

        System.out.println("Brand: " + refrigerator.getBrand());
        System.out.println("Temperature: " + refrigerator.getTemperature());

    }
}