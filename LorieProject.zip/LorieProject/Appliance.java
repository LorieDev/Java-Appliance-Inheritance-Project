package com.LorieProject;

public class Appliance{

    //Field
    private String brand;
    private String watts;

    //Constructor
    public Appliance(String brand, String watts){
        this.brand = brand;
        this.watts = watts;
    }

    //Getter
    public String getBrand (){
        return this.brand;
    }
    public String getWatts(){
        return this.watts;
    }

    //getter
    public void setBrand(String brand){
        this.brand = brand;
    }
    public void setWatts(String watts){
        this.watts = watts;
    }

    //Methods
    public void turnOn(){
        System.out.println("turn on your appliance");
    }


}