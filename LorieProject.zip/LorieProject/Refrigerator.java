package com.LorieProject;

public class Refrigerator extends Appliance {


    //Field
    private String temperature;

    //Constructor
    public Refrigerator(String brand, String watts, String temperature){
        super(brand, watts);
        this.temperature = temperature;
    }

    //Getter
    public String getTemperature() {
        return this.temperature;
    }

    //Setter
    public void setTemperature(String refrigerator){
        this.temperature = refrigerator;
    }

    //Methods
    public void showTemperature(){
        System.out.println("That your frig temperature.");
    }



}
